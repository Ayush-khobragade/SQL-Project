/* =====================================================================
   RCB IPL STRATEGY — STUDENT ANSWER TEMPLATE
   ===================================================================== */

USE ipl;


/* =====================================================================
   OBJECTIVE QUESTIONS
   ===================================================================== */

-- O1
-- List the different dtypes of columns in table "ball_by_ball" (using
-- information schema)

SELECT
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_KEY
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND LOWER(TABLE_NAME) = 'ball_by_ball'
ORDER BY ORDINAL_POSITION;

-- O2
-- What is the total number of runs scored in 1st season by RCB (bonus: also
-- include the extra runs using the extra runs table)

select 
sum(b.Runs_Scored) as Runs_RCB,
coalesce(sum(er.Extra_Runs),0) as Extra_runs,
(sum(b.Runs_Scored) + coalesce(sum(er.Extra_Runs),0)) as Total_runs_RCB
from ball_by_ball b 
join matches m 
on b.Match_id = m.Match_id
join team t 
on t.Team_Id = b.Team_Batting
left join extra_runs er
on er.Match_id = b.Match_id
and er.Over_id = b.Over_id
and er.Ball_id = b.Ball_id
and er.Innings_NO = b.Innings_No
where t.Team_Name = 'Royal Challengers Bangalore'
and m.Season_Id = 6

-- O3
-- How many players were more than the age of 25 during season 2014?

select 
count(distinct p.Player_Id) as Total_players
from player p 
join player_match pm
on p.Player_id = pm.Player_id
join matches m 
on pm.Match_Id = m.Match_Id
join season s 
on s.Season_Id = m.Season_Id
where timestampdiff(year,DOB,m.Match_Date) > 25 
and s.Season_Year = 2014

-- O4
-- How many matches did RCB win in 2013?

select 
count(*) as RCB_Wins_2013
from matches m 
join team t 
on m.Match_Winner = t.Team_id
join Season s 
on s.Season_id = m.Season_id
where s.Season_Year = 2013
and t.Team_Name = 'Royal Challengers Bangalore'

-- O5
-- List the top 10 players according to their strike rate in the last 4
-- seasons

select 
p.Player_Name,
count(*) as total_balls_played,
sum(b.Runs_Scored) as total_runs,
round(100*sum(b.Runs_Scored)/count(*),2) as Strike_rate
from player p 
join ball_by_ball b 
on b.Striker = p.Player_Id
join matches m 
on b.Match_Id = m.Match_Id
join season s 
on s.Season_Id = m.Season_Id
where s.Season_Year >= (select max(Season_Year) - 3)
and b.Innings_No in (1,2)
group by 1
having count(*)>=100
order by Strike_rate desc
limit 10

-- O6
-- What are the average runs scored by each batsman considering all the
-- seasons?

select 
p.Player_Id,
p.Player_Name,
count(distinct m.Match_Id) as total_matches_played,
sum(b.Runs_Scored) as total_runs_scored,
round(sum(b.Runs_Scored)/count(distinct m.Match_Id),2) as avg_runs
from ball_by_ball b 
join matches m 
on b.Match_Id = m.Match_Id
join player p 
on p.Player_Id = b.Striker
group by 1,2
order by avg_runs desc

-- O7
-- What are the average wickets taken by each bowler considering all the
-- seasons?

select 
p.Player_Name,
count(distinct w.Match_Id) as Matches_Bowled,
count(w.Player_Out) as total_wickets,
round(count(w.Player_Out)/count(distinct w.Match_Id),2) as avg_wickets_taken
from wicket_taken w 
join ball_by_ball b
on w.Match_Id = b.Match_Id
and w.Over_Id = b.Over_Id
and w.Ball_Id = b.Ball_Id
and w.Innings_No = b.Innings_No
join player p 
on p.Player_Id = b.Bowler
group by 1
order by avg_wickets_taken desc

-- O8
-- List all the players who have average runs scored greater than the overall
-- average and who have taken wickets greater than the overall average

with batting_stats as (
	select 
    Striker as Player_Id,
    count(distinct Match_Id) as matches_played,
    sum(Runs_Scored) as total_runs,
    round(sum(Runs_Scored)/count(distinct Match_Id),2) as avg_runs
    from ball_by_ball
    group by 1
),
bowling_stats as (
	select 
    Bowler as Player_Id,
    count(distinct w.Match_Id) as total_bowled,
    count(Player_Out) as total_wickets,
    round(count(Player_Out)/count(distinct w.Match_Id),2) as avg_wickets
    from ball_by_ball b
    join wicket_taken w 
    on b.Match_Id = w.Match_Id
    and b.Over_Id = w.Over_Id
    and b.Ball_Id = w.Ball_Id
    and b.Innings_No = w.Innings_No
    group by b.Bowler
)
select 
p.Player_Name,
avg_runs,
avg_wickets
from batting_stats bat
join bowling_stats bowl
on bat.Player_Id = bowl.Player_Id
join player p 
on bat.Player_Id = p.Player_Id
where avg_runs> (select avg(avg_runs) from batting_stats)
and avg_wickets > (select avg(avg_wickets) from bowling_stats)
order by avg_runs desc,avg_wickets desc

-- O9
-- Create a table rcb_record table that shows the wins and losses of RCB in an
-- individual venue.

DROP TABLE IF EXISTS rcb_record;

CREATE TABLE rcb_record AS
SELECT
    v.Venue_Id,
    v.Venue_Name,
    SUM(CASE WHEN m.Match_Winner = rcb.Team_Id THEN 1 ELSE 0 END) AS wins,
    SUM(CASE
            WHEN m.Match_Winner IS NOT NULL
             AND m.Match_Winner <> rcb.Team_Id THEN 1
            ELSE 0
        END) AS losses
FROM Team rcb
JOIN Matches m
    ON m.Team_1 = rcb.Team_Id OR m.Team_2 = rcb.Team_Id
JOIN Venue v
    ON v.Venue_Id = m.Venue_Id
WHERE rcb.Team_Name = 'Royal Challengers Bangalore'
GROUP BY v.Venue_Id, v.Venue_Name;

SELECT Venue_Id, Venue_Name, wins, losses
FROM rcb_record
ORDER BY wins DESC, losses ASC, Venue_Name;

-- O10
-- What is the impact of bowling style on wickets taken?

SELECT
    bs.Bowling_skill AS bowling_style,
    COUNT(*) AS total_wickets,
    COUNT(DISTINCT b.Bowler) AS num_bowlers,
    ROUND(COUNT(*) / NULLIF(COUNT(DISTINCT b.Bowler), 0), 2) AS wickets_per_bowler
FROM Ball_by_Ball b
JOIN Wicket_Taken w
    ON w.Match_Id = b.Match_Id
   AND w.Over_Id = b.Over_Id
   AND w.Ball_Id = b.Ball_Id
   AND w.Innings_No = b.Innings_No
JOIN Out_Type ot
    ON ot.Out_Id = w.Kind_Out
JOIN Player p
    ON p.Player_Id = b.Bowler
JOIN Bowling_Style bs
    ON bs.Bowling_Id = p.Bowling_skill
WHERE ot.Out_Name IN
    ('caught', 'bowled', 'lbw', 'stumped', 'caught and bowled', 'hit wicket')
GROUP BY bs.Bowling_Id, bs.Bowling_skill
ORDER BY total_wickets DESC;

-- O11
-- Write the SQL query to provide a status of whether the performance of the
-- team is better than the previous year's performance on the basis of the
-- number of runs scored by the team in the season and the number of
-- wickets taken

with t1 as (
	select 
	t.Team_Name,
	s.Season_Year,
	sum(b.Runs_Scored) as Total_runs,
	count(w.Player_Out) as Total_Wickets,
	lag(sum(b.Runs_Scored)) over(partition by t.Team_Name order by s.Season_Year) as Prev_year_runs,
	lag(count(w.Player_Out)) over(partition by t.Team_Name order by s.Season_Year) as Prev_year_wickets
	from ball_by_ball b 
	join matches m 
	on b.Match_Id = m.Match_Id
	join team t 
	on t.Team_Id = b.Team_Batting
	join season s 
	on s.Season_Id = m.Season_Id
	left join wicket_taken w 
	on w.Match_Id = b.Match_Id
	and w.Over_Id = b.Over_Id
	and w.Ball_Id = b.Ball_Id
	and w.Innings_No = b.Innings_No
	group by 1,2
	order by Team_Name,Season_Year
)
select *,
case 
	when Total_runs > Prev_year_runs then 'Better'
    when Total_runs < Prev_year_runs then 'Worse'
    else 'Same'
end as Runs_Status,
case
	when Total_Wickets > Prev_year_wickets then 'Better'
    when Total_Wickets < Prev_year_wickets then 'Worse'
    else 'Same'
end as Wickets_status
from t1

-- O12
-- Can you derive more KPIs for the team strategy?

-- kpi 1
SELECT
    s.Season_Year,
    COUNT(DISTINCT m.Match_Id) AS played,
    COUNT(DISTINCT CASE
        WHEN m.Match_Winner = rcb.Team_Id THEN m.Match_Id
    END) AS wins,
    ROUND(
        100.0 * COUNT(DISTINCT CASE
            WHEN m.Match_Winner = rcb.Team_Id THEN m.Match_Id
        END) / NULLIF(COUNT(DISTINCT m.Match_Id), 0),
        2
    ) AS win_pct
FROM Team rcb
JOIN Matches m
    ON m.Team_1 = rcb.Team_Id OR m.Team_2 = rcb.Team_Id
JOIN Season s
    ON s.Season_Id = m.Season_Id
WHERE rcb.Team_Name = 'Royal Challengers Bangalore'
  AND s.Season_Year BETWEEN 2013 AND 2016
GROUP BY s.Season_Year
ORDER BY s.Season_Year;

-- kpi 2
SELECT
    ROUND(
        100.0 * SUM(CASE
            WHEN b.Runs_Scored IN (4, 6) THEN b.Runs_Scored
            ELSE 0
        END) / NULLIF(
            SUM(COALESCE(b.Runs_Scored, 0) + COALESCE(er.Extra_Runs, 0)),
            0
        ),
        2
    ) AS pct_runs_from_boundaries
FROM Ball_by_Ball b
JOIN Team rcb
    ON rcb.Team_Id = b.Team_Batting
LEFT JOIN Extra_Runs er
    ON er.Match_Id = b.Match_Id
   AND er.Over_Id = b.Over_Id
   AND er.Ball_Id = b.Ball_Id
   AND er.Innings_No = b.Innings_No
WHERE rcb.Team_Name = 'Royal Challengers Bangalore';

-- kpi 3
SELECT
    p.Player_Name,
    SUM(COALESCE(b.Runs_Scored, 0)) AS runs
FROM Ball_by_Ball b
JOIN Player p
    ON p.Player_Id = b.Striker
JOIN Team rcb
    ON rcb.Team_Id = b.Team_Batting
WHERE rcb.Team_Name = 'Royal Challengers Bangalore'
GROUP BY p.Player_Id, p.Player_Name
ORDER BY runs DESC
LIMIT 5;

-- O13
-- Using SQL, write a query to find out the average wickets taken by each
-- bowler in each venue. Also, rank the gender according to the average
-- value.

WITH bowler_venue_matches AS (
    SELECT
        m.Venue_Id,
        b.Bowler AS Player_Id,
        COUNT(DISTINCT b.Match_Id) AS matches_bowled
    FROM Ball_by_Ball b
    JOIN Matches m
        ON m.Match_Id = b.Match_Id
    GROUP BY m.Venue_Id, b.Bowler
), bowler_venue_wickets AS (
    SELECT
        m.Venue_Id,
        b.Bowler AS Player_Id,
        COUNT(*) AS wickets
    FROM Ball_by_Ball b
    JOIN Matches m
        ON m.Match_Id = b.Match_Id
    JOIN Wicket_Taken w
        ON w.Match_Id = b.Match_Id
       AND w.Over_Id = b.Over_Id
       AND w.Ball_Id = b.Ball_Id
       AND w.Innings_No = b.Innings_No
    JOIN Out_Type ot
        ON ot.Out_Id = w.Kind_Out
    WHERE ot.Out_Name IN
        ('caught', 'bowled', 'lbw', 'stumped', 'caught and bowled', 'hit wicket')
    GROUP BY m.Venue_Id, b.Bowler
), venue_stats AS (
    SELECT
        v.Venue_Id,
        v.Venue_Name,
        p.Player_Name,
        w.wickets,
        ROUND(w.wickets / NULLIF(m.matches_bowled, 0), 2) AS avg_wickets,
        w.wickets / NULLIF(m.matches_bowled, 0) AS avg_wickets_raw
    FROM bowler_venue_wickets w
    JOIN bowler_venue_matches m
        ON m.Venue_Id = w.Venue_Id
       AND m.Player_Id = w.Player_Id
    JOIN Venue v
        ON v.Venue_Id = w.Venue_Id
    JOIN Player p
        ON p.Player_Id = w.Player_Id
), ranked AS (
    SELECT
        Venue_Id,
        Venue_Name,
        Player_Name,
        wickets,
        avg_wickets,
        RANK() OVER (
            PARTITION BY Venue_Id
            ORDER BY avg_wickets_raw DESC
        ) AS venue_rank
    FROM venue_stats
)
SELECT
    Venue_Name,
    Player_Name,
    wickets,
    avg_wickets,
    venue_rank
FROM ranked
ORDER BY Venue_Name, venue_rank, Player_Name;

-- O14
-- Which of the given players have consistently performed well in past
-- seasons? (will you use any visualization to solve the problem)

WITH season_runs AS (
    SELECT
        p.Player_Id,
        p.Player_Name,
        s.Season_Year,
        SUM(COALESCE(b.Runs_Scored, 0)) AS season_runs
    FROM Ball_by_Ball b
    JOIN Player p
        ON p.Player_Id = b.Striker
    JOIN Matches m
        ON m.Match_Id = b.Match_Id
    JOIN Season s
        ON s.Season_Id = m.Season_Id
    WHERE s.Season_Year BETWEEN 2013 AND 2016
    GROUP BY p.Player_Id, p.Player_Name, s.Season_Year
), ranked_seasons AS (
    SELECT
        Player_Id,
        Player_Name,
        Season_Year,
        season_runs,
        ROW_NUMBER() OVER (
            PARTITION BY Player_Id
            ORDER BY season_runs ASC, Season_Year ASC
        ) AS worst_rank,
        ROW_NUMBER() OVER (
            PARTITION BY Player_Id
            ORDER BY season_runs DESC, Season_Year ASC
        ) AS best_rank
    FROM season_runs
), player_summary AS (
    SELECT
        Player_Id,
        Player_Name,
        COUNT(DISTINCT Season_Year) AS seasons_played,
        ROUND(AVG(season_runs), 2) AS avg_runs_per_season,
        ROUND(STDDEV_POP(season_runs), 2) AS runs_stddev
    FROM season_runs
    GROUP BY Player_Id, Player_Name
    HAVING COUNT(DISTINCT Season_Year) = 4
), season_extremes AS (
    SELECT
        Player_Id,
        MAX(CASE WHEN worst_rank = 1 THEN Season_Year END) AS worst_season,
        MAX(CASE WHEN best_rank = 1 THEN Season_Year END) AS best_season
    FROM ranked_seasons
    GROUP BY Player_Id
)
SELECT
    ps.Player_Name,
    ps.seasons_played,
    ps.avg_runs_per_season,
    se.worst_season,
    se.best_season,
    ps.runs_stddev
FROM player_summary ps
JOIN season_extremes se
    ON se.Player_Id = ps.Player_Id
ORDER BY ps.avg_runs_per_season DESC, ps.runs_stddev ASC;

-- O15
-- Are there players whose performance is more suited to specific venues or
-- conditions? (how would you present this using charts?)

WITH player_venue_stats AS (
    SELECT
        p.Player_Id,
        p.Player_Name,
        v.Venue_Id,
        v.Venue_Name,
        SUM(COALESCE(b.Runs_Scored, 0)) AS runs,
        COUNT(CASE
            WHEN et.Extra_Name IS NULL OR et.Extra_Name <> 'wides' THEN 1
        END) AS balls
    FROM Ball_by_Ball b
    JOIN Player p
        ON p.Player_Id = b.Striker
    JOIN Matches m
        ON m.Match_Id = b.Match_Id
    JOIN Venue v
        ON v.Venue_Id = m.Venue_Id
    LEFT JOIN Extra_Runs er
        ON er.Match_Id = b.Match_Id
       AND er.Over_Id = b.Over_Id
       AND er.Ball_Id = b.Ball_Id
       AND er.Innings_No = b.Innings_No
    LEFT JOIN Extra_Type et
        ON et.Extra_Id = er.Extra_Type_Id
    GROUP BY p.Player_Id, p.Player_Name, v.Venue_Id, v.Venue_Name
    HAVING COUNT(CASE
        WHEN et.Extra_Name IS NULL OR et.Extra_Name <> 'wides' THEN 1
    END) >= 60
)
SELECT
    Player_Name,
    Venue_Name,
    runs,
    balls,
    ROUND(100.0 * runs / NULLIF(balls, 0), 2) AS strike_rate
FROM player_venue_stats
ORDER BY strike_rate DESC, balls DESC
LIMIT 25;


/* =====================================================================
   SUBJECTIVE QUESTIONS
   ===================================================================== */

-- S1
-- How does the toss decision affect the result of the match? (which
-- visualizations could be used to present your answer better) And is the
-- impact limited to only specific venues?

WITH toss_results AS (
    SELECT m.Match_Id, m.Venue_Id, m.Toss_Winner, m.Toss_Decide,
           m.Match_Winner,
           CASE WHEN m.Toss_Winner = m.Match_Winner THEN 1 ELSE 0 END AS toss_winner_won
    FROM Matches m
    WHERE m.Match_Winner IS NOT NULL
)
SELECT v.Venue_Name,
       td.Toss_Name AS toss_decision,
       COUNT(*) AS decided_matches,
       SUM(tr.toss_winner_won) AS toss_winner_wins,
       ROUND(100.0 * AVG(tr.toss_winner_won), 2) AS toss_winner_win_pct
FROM toss_results tr
JOIN Venue v ON v.Venue_Id = tr.Venue_Id
JOIN Toss_Decision td ON td.Toss_Id = tr.Toss_Decide
GROUP BY v.Venue_Name, td.Toss_Name
ORDER BY v.Venue_Name, td.Toss_Name;

-- S2
-- Suggest some of the players who would be best fit for the team.

WITH batting AS (
    SELECT b.Striker AS Player_Id,
           SUM(COALESCE(b.Runs_Scored, 0)) AS runs,
           COUNT(*) AS balls_faced,
           COUNT(DISTINCT b.Match_Id) AS batting_matches
    FROM Ball_by_Ball b
    WHERE b.Team_Batting = 2
    GROUP BY b.Striker
),
bowling AS (
    SELECT b.Bowler AS Player_Id,
           COUNT(w.Player_Out) AS wickets,
           COUNT(DISTINCT b.Match_Id) AS bowling_matches
    FROM Ball_by_Ball b
    LEFT JOIN Wicket_Taken w
      ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id
     AND w.Ball_Id = b.Ball_Id AND w.Innings_No = b.Innings_No
    WHERE b.Team_Bowling = 2
    GROUP BY b.Bowler
)
SELECT p.Player_Name,
       COALESCE(bt.runs, 0) AS runs,
       ROUND(100.0 * COALESCE(bt.runs, 0) / NULLIF(bt.balls_faced, 0), 2) AS strike_rate,
       COALESCE(bw.wickets, 0) AS wickets,
       COALESCE(bw.bowling_matches, 0) AS bowling_matches
FROM Player p
LEFT JOIN batting bt ON bt.Player_Id = p.Player_Id
LEFT JOIN bowling bw ON bw.Player_Id = p.Player_Id
WHERE bt.Player_Id IS NOT NULL OR bw.Player_Id IS NOT NULL
ORDER BY COALESCE(bt.runs, 0) DESC, COALESCE(bw.wickets, 0) DESC
LIMIT 20;

-- S3
-- What are some of the parameters that should be focused on while selecting
-- the players?

WITH batting AS (
    SELECT Striker AS Player_Id,
           SUM(COALESCE(Runs_Scored, 0)) AS runs,
           COUNT(*) AS balls,
           COUNT(DISTINCT Match_Id) AS batting_matches
    FROM Ball_by_Ball
    GROUP BY Striker
),
bowling AS (
    SELECT b.Bowler AS Player_Id,
           COUNT(w.Player_Out) AS wickets,
           COUNT(DISTINCT b.Match_Id) AS bowling_matches
    FROM Ball_by_Ball b
    LEFT JOIN Wicket_Taken w
      ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id
     AND w.Ball_Id = b.Ball_Id AND w.Innings_No = b.Innings_No
    GROUP BY b.Bowler
)
SELECT p.Player_Name,
       COALESCE(bt.runs, 0) AS runs,
       ROUND(100.0 * COALESCE(bt.runs, 0) / NULLIF(bt.balls, 0), 2) AS strike_rate,
       ROUND(1.0 * COALESCE(bt.runs, 0) / NULLIF(bt.batting_matches, 0), 2) AS runs_per_match,
       COALESCE(bw.wickets, 0) AS wickets,
       ROUND(1.0 * COALESCE(bw.wickets, 0) / NULLIF(bw.bowling_matches, 0), 2) AS wickets_per_match
FROM Player p
LEFT JOIN batting bt ON bt.Player_Id = p.Player_Id
LEFT JOIN bowling bw ON bw.Player_Id = p.Player_Id
WHERE bt.Player_Id IS NOT NULL OR bw.Player_Id IS NOT NULL
ORDER BY runs_per_match DESC;

-- S4
-- Which players offer versatility in their skills and can contribute
-- effectively with both bat and ball? (can you visualize the data for the
-- same)

WITH bat AS (
    SELECT Striker AS Player_Id,
           SUM(COALESCE(Runs_Scored, 0)) AS runs,
           COUNT(DISTINCT Match_Id) AS batting_matches
    FROM Ball_by_Ball
    GROUP BY Striker
),
bowl AS (
    SELECT b.Bowler AS Player_Id,
           COUNT(w.Player_Out) AS wickets,
           COUNT(DISTINCT b.Match_Id) AS bowling_matches
    FROM Ball_by_Ball b
    LEFT JOIN Wicket_Taken w
      ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id
     AND w.Ball_Id = b.Ball_Id AND w.Innings_No = b.Innings_No
    GROUP BY b.Bowler
)
SELECT p.Player_Name,
       ROUND(1.0 * bat.runs / NULLIF(bat.batting_matches, 0), 2) AS avg_runs_per_match,
       ROUND(1.0 * bowl.wickets / NULLIF(bowl.bowling_matches, 0), 2) AS avg_wickets_per_match,
       bat.batting_matches, bowl.bowling_matches
FROM Player p
JOIN bat ON bat.Player_Id = p.Player_Id
JOIN bowl ON bowl.Player_Id = p.Player_Id
WHERE bat.batting_matches >= 10 AND bowl.bowling_matches >= 10
ORDER BY avg_runs_per_match DESC, avg_wickets_per_match DESC;

-- S5
-- Are there players whose presence positively influences the morale and
-- performance of the team? (justify your answer using visualization)
-- man of the match
select 
p.Player_Name,
count(*) as MOTM_Awards,
count(distinct m.Season_Id) as Seasons
from matches m
join player p on m.Man_of_the_Match = p.Player_Id
group by p.Player_Id, p.Player_Name
order by MOTM_Awards desc
limit 15;

-- player who won MOTM for RCB
select 
p.Player_Name,
count(*) as MOTM_Awards,
count(distinct m.Season_Id) as Seasons
from matches m
join player p on m.Man_of_the_Match = p.Player_Id
join player_match pm on p.Player_Id = pm.Player_Id 
and m.Match_Id = pm.Match_Id
where pm.Team_Id = 2
group by p.Player_Id, p.Player_Name
order by MOTM_Awards desc
limit 10;

-- S6
-- What would you suggest to RCB before going to the mega auction?

WITH batting AS (
    SELECT Striker AS Player_Id,
           SUM(COALESCE(Runs_Scored, 0)) AS runs,
           COUNT(*) AS balls
    FROM Ball_by_Ball
    WHERE Team_Batting = 2
    GROUP BY Striker
),
bowling AS (
    SELECT b.Bowler AS Player_Id, COUNT(w.Player_Out) AS wickets
    FROM Ball_by_Ball b
    LEFT JOIN Wicket_Taken w
      ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id
     AND w.Ball_Id = b.Ball_Id AND w.Innings_No = b.Innings_No
    WHERE b.Team_Bowling = 2
    GROUP BY b.Bowler
)
SELECT p.Player_Name,
       COALESCE(bt.runs, 0) AS runs,
       ROUND(100.0 * COALESCE(bt.runs, 0) / NULLIF(bt.balls, 0), 2) AS strike_rate,
       COALESCE(bw.wickets, 0) AS wickets
FROM Player p
LEFT JOIN batting bt ON bt.Player_Id = p.Player_Id
LEFT JOIN bowling bw ON bw.Player_Id = p.Player_Id
WHERE bt.Player_Id IS NOT NULL OR bw.Player_Id IS NOT NULL
ORDER BY COALESCE(bt.runs, 0) DESC, COALESCE(bw.wickets, 0) DESC;

-- S7
-- What do you think could be the factors contributing to the high-scoring
-- matches and the impact on viewership and team strategies

with match_runs as (
select 
b.Match_Id,
sum(b.Runs_Scored) as Total_Runs,
count(distinct b.Over_Id) as Total_Overs
from ball_by_ball b
group by b.Match_Id
),
--  Classified matches as high scoring or normal
match_classification as (
select 
Match_Id,
Total_Runs,
case when Total_Runs > (select avg(Total_Runs) from match_runs) 
	then 'High Scoring' 
	else 'Normal' end as Match_Type
from match_runs
)
--  Analyzed factors
select 
mc.Match_Type,
count(*) as Total_Matches,
round(avg(mc.Total_Runs), 2) as Avg_Runs,
v.Venue_Name,
td.Toss_Name as Toss_Decision,
s.Season_Year
from match_classification mc
join matches m on mc.Match_Id = m.Match_Id
join venue v on m.Venue_Id = v.Venue_Id
join toss_decision td on m.Toss_Decide = td.Toss_Id
join season s on m.Season_Id = s.Season_Id
group by mc.Match_Type, v.Venue_Name, td.Toss_Name, s.Season_Year
order by Venue_Name,mc.Match_Type, Avg_Runs desc;

-- This now shows factors like:
-- Which venues produce high scoring matches
-- Which toss decision leads to high scores
-- Which seasons had more high scoring matches

-- Some additional factors for high scoring matches are
-- Factor 1: Venue wise average runs (pitch factor)
select 
v.Venue_Name,
round(avg(match_runs), 2) as Avg_Match_Runs,
count(*) as Total_Matches
from (
select b.Match_Id, m.Venue_Id, sum(b.Runs_Scored) as match_runs
from ball_by_ball b
join matches m on b.Match_Id = m.Match_Id
group by b.Match_Id, m.Venue_Id
) as venue_runs
join venue v on venue_runs.Venue_Id = v.Venue_Id
group by v.Venue_Name
having count(*) >= 3
order by Avg_Match_Runs desc;

-- Factor 2: Powerplay runs correlation with match total
select 
b.Match_Id,
sum(case when b.Over_Id between 1 and 6 
then b.Runs_Scored else 0 end) as Powerplay_Runs,
sum(case when b.Over_Id between 16 and 20 
then b.Runs_Scored else 0 end) as Death_Runs,
sum(b.Runs_Scored) as Total_Runs
from ball_by_ball b
group by b.Match_Id
order by Total_Runs desc
limit 20;


-- S8
-- Analyze the impact of home-ground advantage on team performance and
-- identify strategies to maximize this advantage for RCB.

select 
case when v.Venue_Name = 'M Chinnaswamy Stadium' 
 then 'Home' else 'Away' end as Ground_Type,
count(*) as Total_Matches,
sum(case when m.Match_Winner = 2 then 1 else 0 end) as Wins,
round(sum(case when m.Match_Winner = 2 then 1 else 0 end) * 100.0 / count(*), 2) as Win_Pct
from matches m
join venue v on m.Venue_Id = v.Venue_Id
where m.Team_1 = 2 or m.Team_2 = 2
group by Ground_Type;

-- Chinnaswamy stadium specific player performance (home ground)
select 
p.Player_Name,
count(distinct b.Match_Id) as Matches,
sum(b.Runs_Scored) as Total_Runs,
round(sum(b.Runs_Scored) / count(distinct b.Match_Id), 2) as Avg_Runs,
round(sum(b.Runs_Scored) * 100.0 / count(*), 2) as Strike_Rate
from ball_by_ball b
join player p on b.Striker = p.Player_Id
join matches m on b.Match_Id = m.Match_Id
join venue v on m.Venue_Id = v.Venue_Id
where v.Venue_Name = 'M Chinnaswamy Stadium'
and b.Team_Batting = 2
group by p.Player_Id, p.Player_Name
having count(distinct b.Match_Id) >= 3
order by Avg_Runs desc;

-- S9
-- Come up with a visual and analytical analysis of the RCB's past season's
-- performance and potential reasons for them not winning a trophy.

--  RCB season wise runs and wickets
select 
s.Season_Year,
sum(b.Runs_Scored) as Total_Runs,
count(wt.Player_Out) as Total_Wickets,
count(distinct m.Match_Id) as Matches_Played
from ball_by_ball b
join matches m on b.Match_Id = m.Match_Id
join season s on m.Season_Id = s.Season_Id
left join wicket_taken wt 
on wt.Match_Id = b.Match_Id
and wt.Over_Id = b.Over_Id
and wt.Ball_Id = b.Ball_Id
and wt.Innings_No = b.Innings_No
where b.Team_Batting = 2
group by s.Season_Year
order by s.Season_Year;

-- S9b: RCB win percentage per season
select 
s.Season_Year,
count(distinct m.Match_Id) as Matches,
sum(case when m.Match_Winner = 2 then 1 else 0 end) as Wins,
round(sum(case when m.Match_Winner = 2 then 1 else 0 end) * 100.0 / 
count(distinct m.Match_Id), 2) as Win_Pct
from matches m
join season s on m.Season_Id = s.Season_Id
where m.Team_1 = 2 or m.Team_2 = 2
group by s.Season_Year
order by s.Season_Year;

-- S10
-- How would you approach this problem, if the objective and subjective
-- questions weren't given?



-- S11
-- In the "Match" table, some entries in the "Opponent_Team" column are
-- incorrectly spelled as "Delhi_Capitals" instead of "Delhi_Daredevils".
-- Write an SQL query to replace all occurrences of "Delhi_Capitals" with
-- "Delhi_Daredevils".

Update matches
set Opponent_Team = 'Delhi_Daredevils'
where Opponent_Team = 'Delhi_Capitals';

/* ===================================== END OF FILE ===================================== */
